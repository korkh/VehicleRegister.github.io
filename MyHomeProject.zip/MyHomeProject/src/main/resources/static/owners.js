$(function(){
    receiveAllCars();
});

function receiveAllCars(){
    $.get("/receiveCars",function(cars){
        formattCars(cars);

    });
}

function formattCars(cars){
    let out = "<select id = 'selectedCarType' class='m-1 col-md-4 form-control' onchange='createModel(cars,this.value)'>";
    let out1 = "<select id = 'selectedCarModel' class='m-1 col-md-4 form-control'>"
    console.log(cars);
    let carTypes = [];
    for(const car of cars) {
        if (!carTypes.includes(car.type)) {
            carTypes.push(car.type);
            out += "<option value='" + car.type + "'>" + car.type+ "</option>";
            }
        }

    /*$('#selectedCarTypes').change(function(){
        $('#selectedCarModels').prop('selectedIndex', 0);                    //clean select
        let car = $(this).val();                                             //get value of shoosen type
        if(car != '') {                                                      //check if any type is choosen
            $('#selectedCarModels').attr('disabled',false);                  //open select with models
            $('#selectedCarModels option').css('display','none');            //hide all models initially
            $('#selectedCarModels option.'+ car).css('display','inline');    //open models which we need
        }
        else {
            $('#selectedCarModels').attr('disabled',true); //if no types are selected - hide all models
        }
    });*/

    console.log(cars);
    out += "</select>";
    out1 += "</select>";
    $("#carType").html(out);
    $("#carModel").html(out1);


}

function createModel(dataModel, cars){ //dataModel = this.value from See string 12 "on change=..."
    console.log(dataModel);
    console.log(cars);
    let out1 = "<select id = 'selectedCarModel' class='m-1 col-md-4 form-control'>";
    for(const car of cars){
        if (dataModel === car.type) {
            out1 += "<option value='" + car.model + "'>" + car.model + "</option>";
        }
    }
    out1 += "</select>";
    $("#carModel").html(out1);
    console.log(out1);
}

function createOwner(){
    const owner = {
        name: $("#name").val(),
        secondName: $("#secondName").val(),
        ownedCarType: $("#selectedCarType").val(),
        ownedCarModel: $("#selectedCarModel").val()
    };

    const url = "/createOwner";
    $.post(url, owner, function(){
        window.location.href= '/';
    });
}